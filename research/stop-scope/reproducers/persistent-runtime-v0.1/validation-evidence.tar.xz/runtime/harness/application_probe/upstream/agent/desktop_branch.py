import asyncio
import contextvars
import logging
import re
from collections.abc import Sequence

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, Field

from agent.desktop import is_desktop_worktree
from agent.input_messages import dynamic_context_hash, input_message_text
from agent.prompts import load_prompt

logger = logging.getLogger(__name__)

BRANCH_PREFIX = "open-swe"
TEMPORARY_BRANCH_PREFIX = f"{BRANCH_PREFIX}/local"
MAX_BRANCH_INPUT_CHARS = 4_000
MAX_BRANCH_SLUG_CHARS = 48
BRANCH_GENERATION_TIMEOUT_SECONDS = 10
_TEMPORARY_BRANCH = re.compile(rf"^{re.escape(TEMPORARY_BRANCH_PREFIX)}-[0-9a-f]{{8}}$")
_background_tasks: set[asyncio.Task[None]] = set()
_inflight_paths: set[str] = set()

_BRANCH_SYSTEM_PROMPT = load_prompt("desktop-branch.md")


class _BranchName(BaseModel):
    branch: str = Field(description="Hyphenated lowercase branch name, 2-5 words")


def is_temporary_branch(branch: str) -> bool:
    return bool(_TEMPORARY_BRANCH.match(branch.strip().lower()))


def build_branch_name(raw: str) -> str | None:
    slug = (
        re.sub(r"[^a-z0-9]+", "-", raw.strip().lower())
        .strip("-")[:MAX_BRANCH_SLUG_CHARS]
        .rstrip("-")
    )
    return f"{BRANCH_PREFIX}/{slug}" if slug else None


def _request_text(messages: Sequence[BaseMessage]) -> str | None:
    for message in messages:
        if message.type != "human" or dynamic_context_hash(message.content) is not None:
            continue
        text = (input_message_text(message.content) or message.text).strip()
        if text:
            return text[:MAX_BRANCH_INPUT_CHARS]
    return None


async def _git(cwd: str, *args: str) -> str | None:
    process = await asyncio.create_subprocess_exec(
        "git",
        *args,
        cwd=cwd,
        stdout=asyncio.subprocess.PIPE,
        stderr=asyncio.subprocess.DEVNULL,
    )
    stdout, _ = await process.communicate()
    return stdout.decode().strip() if process.returncode == 0 else None


async def rename_temporary_worktree_branch(
    *, worktree_path: str, request: str, model: BaseChatModel
) -> str | None:
    """Rename a placeholder worktree branch to one that describes the request."""
    current = await _git(worktree_path, "symbolic-ref", "--quiet", "--short", "HEAD")
    if not current or not is_temporary_branch(current):
        return None

    structured = model.with_structured_output(_BranchName)
    async with asyncio.timeout(BRANCH_GENERATION_TIMEOUT_SECONDS):
        result = await structured.ainvoke(
            [
                SystemMessage(content=_BRANCH_SYSTEM_PROMPT),
                HumanMessage(content=request),
            ],
            # Empty callbacks, so this call cannot inherit the run's handlers and
            # stream its tokens into the thread the user is watching.
            config={"callbacks": [], "run_name": "worktree-branch-name"},
        )
    if not isinstance(result, _BranchName):
        return None
    target = build_branch_name(result.branch)
    if not target or target == current:
        return None
    for candidate in (target, *(f"{target}-{suffix}" for suffix in range(2, 10))):
        if await _git(worktree_path, "branch", "-m", "--", current, candidate) is not None:
            return candidate
    return None


def schedule_worktree_branch_rename(
    *, worktree_path: str, messages: Sequence[BaseMessage], model: BaseChatModel
) -> None:
    """Name an app-created worktree's branch without blocking the run."""
    request = _request_text(messages)
    if not request or worktree_path in _inflight_paths or not is_desktop_worktree(worktree_path):
        return
    _inflight_paths.add(worktree_path)

    async def run() -> None:
        try:
            await rename_temporary_worktree_branch(
                worktree_path=worktree_path, request=request, model=model
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Worktree branch rename failed for %s: %s", worktree_path, exc)
        finally:
            _inflight_paths.discard(worktree_path)

    # A fresh context, not the caller's: an inherited context carries LangGraph's
    # stream writer, and this call's structured-output chunks would then be
    # emitted into the run's message stream.
    task = asyncio.get_running_loop().create_task(run(), context=contextvars.Context())
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)
