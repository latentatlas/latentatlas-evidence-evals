"""Tool: ``search_repo_code``. Search the PR's repository via the GitHub code-search API."""

from typing import Any

import httpx2

from agent.github.checks import github_headers
from agent.run_config import RunConfig

_GITHUB_API = "https://api.github.com"


def _chat_repo_context() -> tuple[str, str, str | None]:
    cfg = RunConfig.from_runtime()
    return (cfg.chat_repo_owner or "", cfg.chat_repo_name or "", cfg.chat_github_token or None)


async def search_repo_code(query: str, max_results: int = 20) -> dict[str, Any]:
    """Implement the `search_repo_code` tool."""
    owner, repo, token = _chat_repo_context()
    if not owner or not repo:
        return {"success": False, "error": "repository context unavailable"}
    if not token:
        return {
            "success": False,
            "error": "GitHub credentials unavailable; repository source was not read",
        }

    capped = max(1, min(max_results, 50))
    headers = github_headers(token)
    headers["Accept"] = "application/vnd.github.text-match+json"
    params = {"q": f"{query} repo:{owner}/{repo}", "per_page": capped}
    try:
        async with httpx2.AsyncClient(timeout=30) as client:
            response = await client.get(
                f"{_GITHUB_API}/search/code", headers=headers, params=params
            )
    except httpx2.HTTPError as exc:
        return {"success": False, "error": f"GitHub request failed: {exc!s}"}

    if response.status_code == 422:
        return {"success": False, "error": "query rejected by GitHub code search"}
    if response.status_code >= 400:
        return {"success": False, "error": f"GitHub returned {response.status_code}"}

    payload = response.json()
    items = payload.get("items") if isinstance(payload, dict) else None
    results: list[dict[str, Any]] = []
    for item in items if isinstance(items, list) else []:
        if not isinstance(item, dict):
            continue
        fragments = [
            match.get("fragment")
            for match in item.get("text_matches", [])
            if isinstance(match, dict) and isinstance(match.get("fragment"), str)
        ]
        results.append({"path": item.get("path", ""), "fragments": fragments})
    total = payload.get("total_count") if isinstance(payload, dict) else None
    return {
        "success": True,
        "total_count": total if isinstance(total, int) else len(results),
        "results": results,
    }
