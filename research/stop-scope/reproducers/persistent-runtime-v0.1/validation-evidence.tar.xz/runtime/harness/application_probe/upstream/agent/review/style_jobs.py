"""Kick off and sync per-repo review style analysis runs."""

import logging
from typing import Any

from langgraph_sdk import get_client

from agent.config import ENV
from agent.dispatch import create_durable_run
from agent.input_messages import RunInput, build_run_input
from agent.invocation import new_invocation_id, with_invocation_id
from agent.review.style_collector import (
    collect_review_samples,
    format_samples_for_analyzer,
)
from agent.review.styles import (
    REVIEW_STYLES,
    ReviewStyle,
    reconcile_running_status,
)
from agent.thread_ids import review_style_thread_id
from agent.utils.analyzer_skills import build_skill_files

logger = logging.getLogger(__name__)

_ASSISTANT_ID = "analyzer"


def langgraph_client():
    """LangGraph SDK client for the current deployment (same resolution as webapp)."""
    url = ENV.LANGGRAPH_URL.optional()
    if url:
        return get_client(url=url)
    return get_client()


def build_continual_run_input(full_name: str) -> RunInput:
    """Run input for a continual-learning analyzer run (shared with the cron)."""
    return build_run_input(
        (
            f"Refine the review-style prompt for `{full_name}` using this "
            "reviewer's recorded finding outcomes. Follow the continual-learning "
            "skill, then save the refined prompt."
        ),
        {
            "sender_id": "system:review-style-continual",
            "surface": "automation",
            "kind": "system",
        },
        systems=[
            {
                "id": "system:review-style-continual",
                "display_name": "Review style continual learning",
                "platform": "open-swe",
            }
        ],
        files=build_skill_files(),
    )


def build_continual_run_configurable(full_name: str) -> dict[str, Any]:
    """Configurable for a continual-learning analyzer run (shared with the cron).

    Includes an explicit ``thread_id`` so the run is anchored to the repo's
    deterministic analyzer thread. The nightly cron is threadless, so without
    this ``get_analyzer`` would early-return an empty agent (no thread_id) and
    the run would no-op. Reusing the deterministic id keys the sandbox + thread
    metadata to the repo; the threadless run carries no message history, so it
    does not accumulate across nights.
    """
    owner, repo = full_name.split("/", 1)
    return {
        "thread_id": review_style_thread_id(owner, repo),
        "review_style_full_name": full_name,
        "analyzer_mode": "continual",
    }


async def start_bootstrap_analysis(
    full_name: str,
    *,
    github_token: str,
    created_by: str,
) -> ReviewStyle:
    """Collect samples, persist metadata, and start a bootstrap analyzer run."""
    owner, repo = full_name.split("/", 1)
    try:
        samples = await collect_review_samples(github_token, owner, repo)
    except Exception:
        logger.exception("Failed to collect review samples for %s", full_name)
        return await REVIEW_STYLES.mark_failed(
            full_name, "Sample collection failed. Please retry later."
        )

    samples_text = format_samples_for_analyzer(samples)
    thread_id = review_style_thread_id(owner, repo)

    client = langgraph_client()
    configurable: dict[str, Any] = {
        "thread_id": thread_id,
        "review_style_full_name": full_name,
        "review_style_github_token": github_token,
        "review_style_samples_text": samples_text,
        "review_style_top_reviewers": samples.top_reviewers,
        "review_style_prs_sampled": samples.prs_scanned,
        "review_style_reviews_sampled": samples.reviews_scanned,
        "analyzer_mode": "bootstrap",
    }
    if not samples.samples:
        logger.info(
            "No pre-collected samples for %s (%s merged PRs scanned); analyzer will fetch via API",
            full_name,
            samples.prs_scanned,
        )

    await REVIEW_STYLES.mark_running(
        full_name,
        thread_id=thread_id,
        run_id=None,
        top_reviewers=samples.top_reviewers,
        prs_sampled=samples.prs_scanned,
        reviews_sampled=samples.reviews_scanned,
    )

    try:
        run = await create_durable_run(
            thread_id,
            _ASSISTANT_ID,
            input=build_run_input(
                (
                    f"Analyze review style for `{full_name}`. Follow the "
                    "bootstrap-repo-analysis skill: browse merged PR review feedback "
                    "with `gh` until you have enough human examples, "
                    "then save the repository-specific prompt."
                ),
                {
                    "sender_id": "system:review-style-bootstrap",
                    "surface": "automation",
                    "kind": "system",
                },
                systems=[
                    {
                        "id": "system:review-style-bootstrap",
                        "display_name": "Review style bootstrap",
                        "platform": "open-swe",
                    }
                ],
                files=build_skill_files(),
            ),
            source="review-style-bootstrap",
            config={"configurable": with_invocation_id(configurable, new_invocation_id())},
            client=client,
        )
        run_id = run.get("run_id") if isinstance(run, dict) else getattr(run, "run_id", None)
        return await REVIEW_STYLES.record_run_started(
            full_name, run_id=run_id, created_by=created_by
        )
    except Exception:
        logger.exception("Failed to start review style analyzer for %s", full_name)
        return await REVIEW_STYLES.mark_failed(
            full_name, "Failed to start analysis. Please retry later."
        )


async def start_continual_run(
    full_name: str,
    *,
    created_by: str = "manual",
) -> ReviewStyle:
    """Start an immediate continual-learning run (outcome-driven refinement)."""
    configurable = build_continual_run_configurable(full_name)
    thread_id = configurable["thread_id"]
    try:
        client = langgraph_client()
        run = await create_durable_run(
            thread_id,
            _ASSISTANT_ID,
            input=build_continual_run_input(full_name),
            source="review-style-continual",
            config={"configurable": with_invocation_id(configurable, new_invocation_id())},
            client=client,
        )
        run_id = run.get("run_id") if isinstance(run, dict) else getattr(run, "run_id", None)
        return await REVIEW_STYLES.record_run_started(
            full_name, run_id=run_id, created_by=created_by
        )
    except Exception:
        logger.exception("Failed to start continual analyzer run for %s", full_name)
        return await REVIEW_STYLES.mark_failed(full_name, "run start failed")


async def sync_review_style_run_status(full_name: str) -> ReviewStyle:
    """Refresh store status from the latest analyzer run when still running."""
    record = await REVIEW_STYLES.get_or_seed(full_name)
    if record.status != "running":
        return record

    thread_id = record.analysis_thread_id
    run_id = record.analysis_run_id
    if not thread_id:
        return record

    client = langgraph_client()
    run_status: str | None = None
    run_missing = False
    try:
        if run_id:
            run = await client.runs.get(thread_id, run_id)
        else:
            runs = await client.runs.list(thread_id, limit=1)
            items = runs if isinstance(runs, list) else (runs.get("runs") or [])
            run = items[0] if items else None
        if not run:
            run_missing = True
        else:
            raw = run.get("status") if isinstance(run, dict) else getattr(run, "status", None)
            run_status = raw.lower() if isinstance(raw, str) else None
    except Exception:
        logger.debug("Could not sync run status for %s", full_name, exc_info=True)
        return record

    return await reconcile_running_status(
        full_name, record, run_status=run_status, run_missing=run_missing
    )


async def cancel_review_style_analysis(full_name: str) -> ReviewStyle:
    """Stop an in-flight analyzer run and clear stale ``running`` status."""
    record = await REVIEW_STYLES.get_or_seed(full_name)
    if record.status != "running":
        return record

    if record.analysis_thread_id and record.analysis_run_id:
        try:
            await langgraph_client().runs.cancel(
                record.analysis_thread_id, record.analysis_run_id, wait=False
            )
        except Exception:
            logger.debug("Could not cancel review style run for %s", full_name, exc_info=True)

    if record.has_saved_prompt:
        return await REVIEW_STYLES.mark_completed(full_name)
    return await REVIEW_STYLES.mark_idle(full_name)
