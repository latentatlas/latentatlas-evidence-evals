"""Supported models and reasoning efforts surfaced in the profile editor."""

from collections.abc import Callable, Mapping, Sequence
from functools import cache, lru_cache
from importlib import import_module
from typing import NotRequired, TypedDict, cast

from agent.config import ENV


class ModelOption(TypedDict):
    id: str
    label: str
    efforts: list[str]
    default_effort: str
    supports_images: bool
    can_be_default: NotRequired[bool]
    context_window: NotRequired[int | None]


SUPPORTED_MODELS: list[ModelOption] = [
    {
        "id": "anthropic:claude-opus-5",
        "label": "Opus 5",
        "efforts": ["low", "medium", "high", "xhigh", "max"],
        "default_effort": "high",
        "supports_images": True,
    },
    {
        "id": "anthropic:claude-sonnet-5",
        "label": "Sonnet 5",
        "efforts": ["low", "medium", "high", "xhigh", "max"],
        "default_effort": "high",
        "supports_images": True,
    },
    {
        "id": "anthropic:claude-fable-5-1",
        "label": "Fable 5.1",
        "efforts": ["low", "medium", "high", "xhigh", "max"],
        "default_effort": "high",
        "supports_images": True,
        "can_be_default": False,
    },
    {
        "id": "anthropic:claude-haiku-4-5",
        "label": "Haiku 4.5",
        # Haiku 4.5 predates the adaptive-thinking/effort params the other
        # Claude entries rely on, so it is offered without reasoning.
        "efforts": ["none"],
        "default_effort": "none",
        "supports_images": True,
    },
    {
        "id": "openai:gpt-6-astra",
        "label": "GPT-6 Astra",
        "efforts": ["low", "medium", "high", "xhigh", "max"],
        "default_effort": "xhigh",
        "supports_images": True,
    },
    {
        "id": "openai:gpt-5.6-sol",
        "label": "GPT-5.6 Sol",
        "efforts": ["none", "low", "medium", "high", "xhigh"],
        "default_effort": "xhigh",
        "supports_images": True,
    },
    {
        "id": "openai:gpt-5.6-terra",
        "label": "GPT-5.6 Terra",
        "efforts": ["none", "low", "medium", "high", "xhigh"],
        "default_effort": "xhigh",
        "supports_images": True,
    },
    {
        "id": "openai:gpt-5.6-luna",
        "label": "GPT-5.6 Luna",
        "efforts": ["none", "low", "medium", "high", "xhigh", "max"],
        "default_effort": "xhigh",
        "supports_images": True,
    },
    {
        "id": "google_genai:gemini-3.8-flash",
        "label": "Gemini 3.8 Flash",
        "efforts": ["minimal", "low", "medium", "high"],
        "default_effort": "medium",
        "supports_images": True,
    },
    {
        "id": "fireworks:accounts/fireworks/models/kimi-k3",
        "label": "Kimi K3",
        # K3 always reasons and only accepts low/high/max — "medium" is rejected.
        "efforts": ["low", "high", "max"],
        "default_effort": "high",
        "supports_images": False,
    },
    {
        "id": "fireworks:accounts/fireworks/models/deepseek-v4-pro",
        "label": "DeepSeek V4 Pro",
        "efforts": ["none", "low", "medium", "high", "xhigh", "max"],
        "default_effort": "high",
        "supports_images": False,
    },
    {
        "id": "fireworks:accounts/fireworks/models/glm-5p3",
        "label": "GLM 5.3",
        "efforts": ["none", "high", "max"],
        "default_effort": "high",
        "supports_images": False,
    },
    {
        "id": "fireworks:accounts/fireworks/models/glm-5p3-flash",
        "label": "GLM-5.3 Flash",
        "efforts": ["low", "high", "max"],
        "default_effort": "high",
        "supports_images": True,
    },
]

SUPPORTED_MODEL_IDS: frozenset[str] = frozenset(m["id"] for m in SUPPORTED_MODELS)

FABLE_MODEL_IDS: frozenset[str] = frozenset(
    m["id"] for m in SUPPORTED_MODELS if m["id"].startswith("anthropic:claude-fable")
)
NON_DEFAULT_MODEL_IDS: frozenset[str] = frozenset(
    m["id"] for m in SUPPORTED_MODELS if not m.get("can_be_default", True)
)

DEPRECATED_MODEL_IDS: frozenset[str] = frozenset(
    {
        "anthropic:claude-opus-4-8",
        "anthropic:claude-fable-5",
        "openai:gpt-5.5",
        "google_genai:gemini-3.5-flash",
        "google_genai:gemini-3.6-flash",
        "google_genai:gemini-3.7-flash",
        "fireworks:accounts/fireworks/models/kimi-k2p7-code",
        "fireworks:accounts/fireworks/models/kimi-k3-code",
        "fireworks:accounts/fireworks/models/glm-5p2",
    }
)

DEPRECATED_MODEL_REPLACEMENTS: dict[str, str] = dict.fromkeys(DEPRECATED_MODEL_IDS, "")

ProfileLoader = Callable[[str], Mapping[str, object]]

# LangChain partner packages expose ``_get_default_model_profile`` — the same
# accessor that populates ``ChatModel.profile`` from bundled models.dev data.
_PROFILE_LOADER_MODULES: dict[str, str] = {
    "anthropic": "langchain_anthropic.chat_models",
    "fireworks": "langchain_fireworks.chat_models",
    "google_genai": "langchain_google_genai.chat_models",
    "openai": "langchain_openai.chat_models.base",
}
CODEX_CONTEXT_WINDOW_OVERRIDES: dict[str, int] = {
    "openai:gpt-6-astra": 272_000,
    "openai:gpt-5.6-sol": 272_000,
    "openai:gpt-5.6-terra": 272_000,
    "openai:gpt-5.6-luna": 272_000,
}
_PROFILE_CONTEXT_WINDOW_FALLBACKS: dict[str, int] = {
    "fireworks:accounts/fireworks/models/kimi-k3": 1_048_576,
    "fireworks:accounts/fireworks/models/glm-5p3": 1_048_576,
    "fireworks:accounts/fireworks/models/glm-5p3-flash": 1_048_576,
}


@cache
def _profile_loader(provider: str) -> ProfileLoader | None:
    module_path = _PROFILE_LOADER_MODULES.get(provider)
    if module_path is None:
        return None
    try:
        module = import_module(module_path)
    except ImportError:
        return None
    loader = getattr(module, "_get_default_model_profile", None)
    if not callable(loader):
        return None
    return cast(ProfileLoader, loader)


def model_profile_with_context_override(model_id: str) -> dict[str, object] | None:
    context_window = CODEX_CONTEXT_WINDOW_OVERRIDES.get(model_id)
    if context_window is None:
        return None
    provider, _, model_name = model_id.partition(":")
    loader = _profile_loader(provider)
    profile = dict(loader(model_name)) if loader is not None else {}
    profile["max_input_tokens"] = context_window
    return profile


@lru_cache(maxsize=512)
def model_profile_context_window(model_id: str) -> int | None:
    context_window = CODEX_CONTEXT_WINDOW_OVERRIDES.get(model_id)
    if context_window is not None:
        return context_window
    provider, _, model_name = model_id.partition(":")
    if not provider or not model_name:
        return None
    loader = _profile_loader(provider)
    if loader is not None:
        profile = loader(model_name)
        context_window = profile.get("max_input_tokens")
        if isinstance(context_window, int) and context_window > 0:
            return context_window
    return _PROFILE_CONTEXT_WINDOW_FALLBACKS.get(model_id)


def models_with_profile_context_windows(models: Sequence[ModelOption]) -> list[ModelOption]:
    enriched: list[ModelOption] = []
    for model in models:
        option: ModelOption = {
            "id": model["id"],
            "label": model["label"],
            "efforts": model["efforts"],
            "default_effort": model["default_effort"],
            "supports_images": model["supports_images"],
        }
        if "can_be_default" in model:
            option["can_be_default"] = model["can_be_default"]
        context_window = model_profile_context_window(model["id"])
        if context_window is not None:
            option["context_window"] = context_window
        enriched.append(option)
    return enriched


def fable_disabled_fallback(effort: object = None) -> tuple[str, str]:
    """Newest supported non-Fable Anthropic model (keeps the Claude family),
    else the global default. Substitutes a Fable selection when Fable is
    disabled workspace-wide, preserving ``effort`` when the fallback supports it."""
    for m in SUPPORTED_MODELS:
        if m["id"].startswith("anthropic:") and m["id"] not in FABLE_MODEL_IDS:
            return m["id"], _fallback_effort_for(m, effort) or m["default_effort"]
    return default_model_pair()


def gate_fable_model(
    model_id: str, effort: str | None, *, fable_enabled: bool
) -> tuple[str, str | None]:
    """ZDR guard: if Fable is disabled but a Fable id was resolved, swap in a
    safe non-Fable model. Non-Fable selections pass through unchanged. Applied
    at every model-construction entrypoint so a disabled Fable model can never
    reach ``make_model``, no matter which layer selected it."""
    if not fable_enabled and isinstance(model_id, str) and model_id in FABLE_MODEL_IDS:
        return fable_disabled_fallback(effort)
    return model_id, effort


DEFAULT_MODEL_ID: str = (
    "anthropic:claude-opus-5"
    if ENV.ANTHROPIC_API_KEY.optional() and not ENV.OPENAI_API_KEY.optional()
    else "openai:gpt-5.6-sol"
)
DEFAULT_MODEL_EFFORT: str = "medium"


def model_supports_effort(model_id: str, effort: str) -> bool:
    for m in SUPPORTED_MODELS:
        if m["id"] == model_id:
            return effort in m["efforts"]
    return False


def model_supports_images(model_id: str) -> bool:
    for m in SUPPORTED_MODELS:
        if m["id"] == model_id:
            return m["supports_images"]
    return False


def _provider_of(model_id: str) -> str | None:
    provider, _, rest = model_id.partition(":")
    return provider if rest else None


def _claude_family_of(model_id: str) -> str | None:
    provider, _, name = model_id.partition(":")
    if provider != "anthropic" or not name.startswith("claude-"):
        return None
    parts = name.split("-")
    if len(parts) < 2:
        return None
    return "-".join(parts[:2])


def _fallback_effort_for(model: ModelOption, effort: object) -> str | None:
    if not isinstance(effort, str):
        return None
    if effort in model["efforts"]:
        return effort
    if (
        model["id"].startswith("google_genai:")
        and effort == "none"
        and "minimal" in model["efforts"]
    ):
        return "minimal"
    return None


def is_deprecated_model(model_id: object) -> bool:
    return isinstance(model_id, str) and model_id in DEPRECATED_MODEL_IDS


def canonical_model_pair(model_id: object, effort: object = None) -> tuple[str, str] | None:
    return None


def normalize_model_choice(model_id: object, effort: object) -> tuple[str | None, str | None]:
    if (
        not isinstance(model_id, str)
        or model_id not in SUPPORTED_MODEL_IDS
        or not isinstance(effort, str)
        or not model_supports_effort(model_id, effort)
    ):
        return None, None
    return model_id, effort


def provider_fallback_pair(model_id: object, effort: object = None) -> tuple[str, str] | None:
    """Newest supported ``(model_id, effort)`` for the same provider/family.

    Keeps a stored selection on its original provider when its exact id has
    dropped out of the supported set (e.g. an Opus minor-version bump), preferring
    the same Claude family when available instead of falling through to the
    cross-provider global default. Preserves ``effort`` when the fallback model
    supports it, otherwise uses that model's default effort. Returns ``None`` when
    no supported model shares the provider.

    Explicitly deprecated ids inherit the team default instead.
    """
    if not isinstance(model_id, str) or model_id in DEPRECATED_MODEL_IDS:
        return None
    provider = _provider_of(model_id)
    if provider is None:
        return None
    family = _claude_family_of(model_id)
    if family is not None:
        for m in SUPPORTED_MODELS:
            if _provider_of(m["id"]) == provider and _claude_family_of(m["id"]) == family:
                return m["id"], _fallback_effort_for(m, effort) or m["default_effort"]
    for m in SUPPORTED_MODELS:
        if _provider_of(m["id"]) == provider:
            return m["id"], _fallback_effort_for(m, effort) or m["default_effort"]
    return None


def default_model_pair() -> tuple[str, str]:
    """Deployment fallback used when no team default is set."""
    model_id = ENV.LLM_MODEL_ID.get(DEFAULT_MODEL_ID)
    effort = ENV.LLM_REASONING_EFFORT.get()
    for model in SUPPORTED_MODELS:
        if model["id"] == model_id and model.get("can_be_default", True):
            effort = (
                effort
                or _fallback_effort_for(model, DEFAULT_MODEL_EFFORT)
                or model["default_effort"]
            )
            if effort not in model["efforts"]:
                raise ValueError(f"Unsupported LLM_REASONING_EFFORT {effort!r} for {model_id!r}")
            return model_id, effort
    raise ValueError(f"Unsupported default LLM_MODEL_ID: {model_id!r}")


def default_vision_model_pair() -> tuple[str, str]:
    """Default OpenAI/Anthropic model pair to use when image input is required."""
    if (
        DEFAULT_MODEL_ID in SUPPORTED_MODEL_IDS
        and model_supports_images(DEFAULT_MODEL_ID)
        and model_supports_effort(DEFAULT_MODEL_ID, DEFAULT_MODEL_EFFORT)
        and DEFAULT_MODEL_ID.startswith(("openai:", "anthropic:"))
    ):
        return DEFAULT_MODEL_ID, DEFAULT_MODEL_EFFORT
    for model in SUPPORTED_MODELS:
        if model["id"].startswith(("openai:", "anthropic:")) and model["supports_images"]:
            return model["id"], model["default_effort"]
    return default_model_pair()
