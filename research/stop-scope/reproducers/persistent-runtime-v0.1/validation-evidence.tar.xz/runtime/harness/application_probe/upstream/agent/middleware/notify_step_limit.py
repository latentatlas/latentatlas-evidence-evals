"""After-agent middleware that notifies users when the step limit is reached."""

import logging
from typing import Any

from langchain.agents.middleware import AgentState, after_agent
from langgraph.runtime import Runtime
from langgraph_sdk import get_client

from agent.middleware.message_content import content_to_text
from agent.middleware.trace import scrub_middleware_inputs
from agent.run_config import RunConfig
from agent.slack.client import (
    LANGGRAPH_URL,
    get_active_slack_thread,
    post_slack_thread_reply,
)
from agent.utils.user_messages import warning

logger = logging.getLogger(__name__)

_LIMIT_MARKER = "Model call limits exceeded"


@scrub_middleware_inputs
@after_agent
async def notify_step_limit_reached(
    state: AgentState,
    runtime: Runtime,
) -> dict[str, Any] | None:
    """Notify the user via Slack when the agent hits its step limit.

    Runs after the agent exits. Checks whether the last AI message contains
    the ``ModelCallLimitMiddleware`` marker text; if so, posts a Slack thread
    reply so the user is not left wondering what happened.
    """
    messages = state.get("messages", [])
    if not messages:
        return None

    last_msg = messages[-1]
    content = content_to_text(getattr(last_msg, "content", "") or "")

    if _LIMIT_MARKER not in content:
        return None

    cfg = RunConfig.from_runtime()
    active = await get_active_slack_thread(
        get_client(url=LANGGRAPH_URL),
        cfg.thread_id,
        cfg.slack_thread.dump() if cfg.slack_thread else None,
    )
    if not active:
        logger.info("No Slack thread config — cannot send step-limit notification")
        return None

    channel_id = active.get("channel_id")
    thread_ts = active.get("thread_ts")

    if (
        not isinstance(channel_id, str)
        or not isinstance(thread_ts, str)
        or not channel_id
        or not thread_ts
    ):
        logger.info("No Slack thread config — cannot send step-limit notification")
        return None

    message = warning(
        "Open SWE reached its maximum step limit and had to stop. "
        "The task may be incomplete. You can retry with a more focused request, "
        "or ask it to continue from where it left off."
    )

    try:
        await post_slack_thread_reply(
            channel_id,
            thread_ts,
            message,
            agent_thread_id=cfg.thread_id,
        )
        logger.info("Sent step-limit notification to Slack thread %s", thread_ts)
    except Exception:
        logger.exception("Failed to send step-limit notification")

    return None
