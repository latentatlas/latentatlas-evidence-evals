"""GitHub webhook comment utilities."""

import asyncio
import hashlib
import hmac
import logging
import re
from typing import Any

import httpx2

from agent.config import ENV
from agent.github.thread_token import GitHubAuthError
from agent.prompts import render_prompt
from agent.utils.http import DEFAULT_HTTP_TIMEOUT

logger = logging.getLogger(__name__)

__all__ = [
    "GitHubAuthError",
    "OPEN_SWE_TAGS",
    "build_pr_prompt",
    "describe_open_swe_tags",
    "extract_pr_context",
    "fetch_github_thread_participants",
    "fetch_issue_comments",
    "fetch_pr_branch",
    "fetch_pr_comments_since_last_tag",
    "format_github_comment_body_for_prompt",
    "mentions_open_swe",
    "post_github_comment",
    "react_to_github_comment",
    "sanitize_github_comment_body",
    "verify_github_signature",
]

_DEFAULT_OPEN_SWE_TAGS = ("@openswe", "@open-swe", "@openswe-dev")


def _load_open_swe_tags() -> tuple[str, ...]:
    configured = tuple(
        tag.strip().lower() for tag in ENV.OPEN_SWE_MENTION_TAGS.get().split(",") if tag.strip()
    )
    return configured or _DEFAULT_OPEN_SWE_TAGS


OPEN_SWE_TAGS = _load_open_swe_tags()

# Deployments sharing a workspace each own a distinct handle, so a tag must not
# match when it is only a prefix of a longer one (@openswe vs @openswe-preview).
_OPEN_SWE_TAG_RE = re.compile(
    "(?:"
    + "|".join(re.escape(tag) for tag in sorted(OPEN_SWE_TAGS, key=len, reverse=True))
    + r")(?![\w-])",
    re.IGNORECASE,
)


def mentions_open_swe(text: str | None) -> bool:
    """Whether text mentions one of this deployment's handles."""
    return bool(text) and _OPEN_SWE_TAG_RE.search(text or "") is not None


def describe_open_swe_tags() -> str:
    """Human-readable handle list for ignore reasons in webhook responses."""
    return " or ".join(OPEN_SWE_TAGS)


UNTRUSTED_GITHUB_COMMENT_OPEN_TAG = "<dangerous-external-untrusted-users-comment>"
UNTRUSTED_GITHUB_COMMENT_CLOSE_TAG = "</dangerous-external-untrusted-users-comment>"
_SANITIZED_UNTRUSTED_GITHUB_COMMENT_OPEN_TAG = "[blocked-untrusted-comment-tag-open]"
_SANITIZED_UNTRUSTED_GITHUB_COMMENT_CLOSE_TAG = "[blocked-untrusted-comment-tag-close]"

# Reaction endpoint differs per comment type
_REACTION_ENDPOINTS: dict[str, str] = {
    "issue_comment": "https://api.github.com/repos/{owner}/{repo}/issues/comments/{comment_id}/reactions",
    "pull_request_review_comment": "https://api.github.com/repos/{owner}/{repo}/pulls/comments/{comment_id}/reactions",
    "pull_request_review": "https://api.github.com/repos/{owner}/{repo}/pulls/{pull_number}/reviews/{comment_id}/reactions",
}

PAGINATED_MAX_PAGES = 50


def verify_github_signature(body: bytes, signature: str, *, secret: str) -> bool:
    """Verify the GitHub webhook signature (X-Hub-Signature-256).

    Args:
        body: Raw request body bytes.
        signature: The X-Hub-Signature-256 header value.
        secret: The webhook signing secret.

    Returns:
        True if signature is valid or no secret is configured.
    """
    if not secret:
        logger.warning("GITHUB_WEBHOOK_SECRET is not configured — rejecting webhook request")
        return False

    if not signature:
        return False

    expected = "sha256=" + hmac.new(secret.encode(), body, hashlib.sha256).hexdigest()
    return hmac.compare_digest(expected, signature)


def derive_pr_state(*, state: str | None, merged: bool, draft: bool) -> str:
    """Map GitHub PR fields to the dashboard's pr_state vocabulary."""
    if merged:
        return "merged"
    if state == "closed":
        return "closed"
    if draft:
        return "draft"
    return "open"


def sanitize_github_comment_body(body: str) -> str:
    """Strip reserved trust wrapper tags from raw GitHub comment bodies."""
    sanitized = body.replace(
        UNTRUSTED_GITHUB_COMMENT_OPEN_TAG,
        _SANITIZED_UNTRUSTED_GITHUB_COMMENT_OPEN_TAG,
    ).replace(
        UNTRUSTED_GITHUB_COMMENT_CLOSE_TAG,
        _SANITIZED_UNTRUSTED_GITHUB_COMMENT_CLOSE_TAG,
    )
    if sanitized != body:
        logger.warning("Sanitized reserved untrusted-comment tags from GitHub comment body")
    return sanitized


def format_github_comment_body_for_prompt(author: str, body: str) -> str:
    """Format a GitHub comment body for prompt inclusion."""
    sanitized_body = sanitize_github_comment_body(body)
    from agent.dashboard.user_mappings import is_login_mapped

    if is_login_mapped(author):
        return sanitized_body

    return (
        f"{UNTRUSTED_GITHUB_COMMENT_OPEN_TAG}\n"
        f"{sanitized_body}\n"
        f"{UNTRUSTED_GITHUB_COMMENT_CLOSE_TAG}"
    )


async def react_to_github_comment(
    repo_config: dict[str, str],
    comment_id: int,
    *,
    event_type: str,
    token: str,
    pull_number: int | None = None,
    node_id: str | None = None,
) -> bool:
    if event_type == "pull_request_review":
        return await _react_via_graphql(node_id, token=token)

    owner = repo_config.get("owner", "")
    repo = repo_config.get("name", "")

    url_template = _REACTION_ENDPOINTS.get(event_type, _REACTION_ENDPOINTS["issue_comment"])
    url = url_template.format(
        owner=owner, repo=repo, comment_id=comment_id, pull_number=pull_number
    )

    async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as http_client:
        try:
            response = await http_client.post(
                url,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                    "X-GitHub-Api-Version": "2022-11-28",
                },
                json={"content": "eyes"},
            )
            if response.status_code == 401:
                raise GitHubAuthError(f"GitHub returned 401 reacting to comment {comment_id}")
            # 200 = already reacted, 201 = just created
            return response.status_code in (200, 201)
        except GitHubAuthError:
            raise
        except Exception:
            logger.exception("Failed to react to GitHub comment %s", comment_id)
            return False


async def _react_via_graphql(node_id: str | None, *, token: str) -> bool:
    """Add a 👀 reaction via GitHub GraphQL API (for PR review bodies)."""
    if not node_id:
        logger.warning("No node_id provided for GraphQL reaction")
        return False

    query = """
    mutation AddReaction($subjectId: ID!) {
    addReaction(input: {subjectId: $subjectId, content: EYES}) {
        reaction { content }
    }
    }
    """
    async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as http_client:
        try:
            response = await http_client.post(
                "https://api.github.com/graphql",
                headers={"Authorization": f"Bearer {token}"},
                json={"query": query, "variables": {"subjectId": node_id}},
            )
            if response.status_code == 401:
                raise GitHubAuthError(
                    f"GitHub returned 401 reacting via GraphQL for node {node_id}"
                )
            data = response.json()
            if "errors" in data:
                logger.warning("GraphQL reaction errors: %s", data["errors"])
                return False
            return True
        except GitHubAuthError:
            raise
        except Exception:
            logger.exception("Failed to react via GraphQL for node_id %s", node_id)
            return False


async def post_github_comment(
    repo_config: dict[str, str],
    issue_number: int,
    body: str,
    *,
    token: str,
) -> bool:
    """Post a comment to a GitHub issue or PR."""
    owner = repo_config.get("owner", "")
    repo = repo_config.get("name", "")
    url = f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments"
    async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as client:
        try:
            response = await client.post(
                url,
                json={"body": body},
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/vnd.github+json",
                },
            )
            response.raise_for_status()
            return True
        except httpx2.HTTPError:
            logger.exception("Failed to post comment to GitHub issue/PR #%s", issue_number)
            return False


async def fetch_github_thread_participants(
    repo_config: dict[str, str], issue_number: int, *, token: str
) -> set[str] | None:
    """Return mapped-candidate GitHub logins that authored an issue or PR thread."""
    owner = repo_config.get("owner", "")
    repo = repo_config.get("name", "")
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    try:
        async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as http_client:
            issue_response = await http_client.get(
                f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}",
                headers=headers,
            )
            if issue_response.status_code == 401:
                raise GitHubAuthError(f"GitHub returned 401 fetching issue {issue_number}")
            if issue_response.status_code != 200:  # noqa: PLR2004
                return None
            issue = issue_response.json()
            comments, review_comments, reviews = await asyncio.gather(
                _fetch_paginated(
                    http_client,
                    f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments",
                    headers,
                ),
                _fetch_paginated(
                    http_client,
                    f"https://api.github.com/repos/{owner}/{repo}/pulls/{issue_number}/comments",
                    headers,
                ),
                _fetch_paginated(
                    http_client,
                    f"https://api.github.com/repos/{owner}/{repo}/pulls/{issue_number}/reviews",
                    headers,
                ),
            )
    except GitHubAuthError:
        return None
    except Exception:
        logger.exception(
            "Failed to fetch GitHub participants for %s/%s#%s", owner, repo, issue_number
        )
        return None

    users = [issue.get("user")]
    users.extend(item.get("user") for item in [*comments, *review_comments, *reviews])
    return {
        login.strip()
        for user in users
        if isinstance(user, dict)
        and user.get("type") != "Bot"
        and isinstance(login := user.get("login"), str)
        and login.strip()
        and not login.lower().endswith("[bot]")
    }


async def fetch_issue_comments(
    repo_config: dict[str, str], issue_number: int, *, token: str | None = None
) -> list[dict[str, Any]]:
    """Fetch all comments for a GitHub issue."""
    owner = repo_config.get("owner", "")
    repo = repo_config.get("name", "")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"

    async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as http_client:
        comments = await _fetch_paginated(
            http_client,
            f"https://api.github.com/repos/{owner}/{repo}/issues/{issue_number}/comments",
            headers,
        )

    return [
        {
            "body": comment.get("body", ""),
            "author": comment.get("user", {}).get("login", "unknown"),
            "created_at": comment.get("created_at", ""),
            "comment_id": comment.get("id"),
        }
        for comment in comments
    ]


async def fetch_pr_comments_since_last_tag(
    repo_config: dict[str, str],
    pr_number: int,
    *,
    token: str,
    event_comment: dict[str, Any] | None = None,
    authorized_login: str | None = None,
) -> list[dict[str, Any]]:
    """Fetch all PR comments/reviews since the last @open-swe tag.

    Fetches from all 3 GitHub comment sources, merges and sorts chronologically,
    then returns every comment from the last @open-swe mention onwards.

    For inline review comments the dict also includes:
    - 'path': file path commented on
    - 'line': line number
    - 'comment_id': GitHub comment ID (for future reply tooling)

    Args:
        repo_config: Dict with 'owner' and 'name' keys.
        pr_number: The pull request number.
        token: GitHub access token.

    Returns:
        List of comment dicts ordered chronologically from last @open-swe tag.
    """
    owner = repo_config.get("owner", "")
    repo = repo_config.get("name", "")
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }

    all_comments: list[dict[str, Any]] = []

    async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as http_client:
        pr_comments, review_comments, reviews = await asyncio.gather(
            _fetch_paginated(
                http_client,
                f"https://api.github.com/repos/{owner}/{repo}/issues/{pr_number}/comments",
                headers,
            ),
            _fetch_paginated(
                http_client,
                f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/comments",
                headers,
            ),
            _fetch_paginated(
                http_client,
                f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}/reviews",
                headers,
            ),
        )

    for c in pr_comments:
        all_comments.append(
            {
                "body": c.get("body", ""),
                "author": c.get("user", {}).get("login", "unknown"),
                "created_at": c.get("created_at", ""),
                "type": "pr_comment",
                "comment_id": c.get("id"),
            }
        )
    for c in review_comments:
        all_comments.append(
            {
                "body": c.get("body", ""),
                "author": c.get("user", {}).get("login", "unknown"),
                "created_at": c.get("created_at", ""),
                "type": "review_comment",
                "comment_id": c.get("id"),
                "review_id": c.get("pull_request_review_id"),
                "path": c.get("path", ""),
                "line": c.get("line") or c.get("original_line"),
            }
        )
    for r in reviews:
        body = r.get("body", "")
        if not body:
            continue
        all_comments.append(
            {
                "body": body,
                "author": r.get("user", {}).get("login", "unknown"),
                "created_at": r.get("submitted_at", ""),
                "type": "review",
                "comment_id": r.get("id"),
            }
        )

    if event_comment is not None:
        event_at = event_comment.get("event_at") or event_comment["created_at"]
        all_comments = [
            c
            for c in all_comments
            if (c["type"], c.get("comment_id"))
            != (event_comment["type"], event_comment["comment_id"])
            and (
                c.get("created_at", "") < event_at
                or (
                    event_comment["type"] == "review"
                    and c.get("review_id") == event_comment["comment_id"]
                )
                or (
                    c["type"] == event_comment["type"]
                    and c.get("created_at", "") == event_at
                    and c.get("comment_id", 0) < event_comment["comment_id"]
                )
            )
        ]
        all_comments.append(event_comment)

    if authorized_login is not None:
        all_comments = [c for c in all_comments if c["author"].lower() == authorized_login.lower()]

    # Sort all comments chronologically
    all_comments.sort(key=lambda c: c.get("event_at") or c.get("created_at", ""))

    tag_indices = [
        i for i, comment in enumerate(all_comments) if mentions_open_swe(comment.get("body"))
    ]

    if not tag_indices:
        return []

    # If this is the first @openswe invocation (only one tag), return ALL
    # comments so the agent has full context — inline review comments are
    # drafted before submission and appear earlier in the sorted list.
    # For repeat invocations, return everything since the previous tag.
    start = 0 if len(tag_indices) == 1 else tag_indices[-2] + 1
    return all_comments[start:]


async def fetch_pr_branch(
    repo_config: dict[str, str], pr_number: int, *, token: str | None = None
) -> str:
    """Fetch the head branch name of a PR from the GitHub API.

    Used for issue_comment events where the branch is not in the webhook payload.
    Token is optional — omitting it makes an unauthenticated request (lower rate limit).

    Args:
        repo_config: Dict with 'owner' and 'name' keys.
        pr_number: The pull request number.
        token: GitHub access token (optional).

    Returns:
        The head branch name, or empty string if not found.
    """
    owner = repo_config.get("owner", "")
    repo = repo_config.get("name", "")
    headers = {
        "Accept": "application/vnd.github+json",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    if token:
        headers["Authorization"] = f"Bearer {token}"
    try:
        async with httpx2.AsyncClient(timeout=DEFAULT_HTTP_TIMEOUT) as http_client:
            response = await http_client.get(
                f"https://api.github.com/repos/{owner}/{repo}/pulls/{pr_number}",
                headers=headers,
            )
            if response.status_code == 200:  # noqa: PLR2004
                return response.json().get("head", {}).get("ref", "")
    except Exception:
        logger.exception("Failed to fetch branch for PR %s", pr_number)
    return ""


async def extract_pr_context(
    payload: dict[str, Any], event_type: str
) -> tuple[dict[str, str], int | None, str, str, str, int | None, str | None]:
    """Extract key fields from a GitHub PR webhook payload.

    Returns:
        (repo_config, pr_number, branch_name, github_login, pr_url, comment_id, node_id)
    """
    repo = payload.get("repository", {})
    repo_config = {"owner": repo.get("owner", {}).get("login", ""), "name": repo.get("name", "")}

    pr_data = payload.get("pull_request") or payload.get("issue", {})
    pr_number = pr_data.get("number")
    pr_url = pr_data.get("html_url", "") or pr_data.get("url", "")
    branch_name = (payload.get("pull_request") or {}).get("head", {}).get("ref", "")

    if not branch_name and pr_number:
        branch_name = await fetch_pr_branch(repo_config, pr_number)

    github_login = payload.get("sender", {}).get("login", "")

    comment = payload.get("comment") or payload.get("review", {})
    comment_id = comment.get("id")
    node_id = comment.get("node_id") if event_type == "pull_request_review" else None

    return repo_config, pr_number, branch_name, github_login, pr_url, comment_id, node_id


def build_pr_prompt(
    comments: list[dict[str, Any]],
    pr_url: str,
    repo_config: dict[str, str] | None = None,
) -> str:
    """Format PR comments into a human message for the agent."""
    lines: list[str] = []
    for c in comments:
        author = c.get("author", "unknown")
        body = format_github_comment_body_for_prompt(author, c.get("body", ""))
        if c.get("type") == "review_comment":
            path = c.get("path", "")
            line = c.get("line", "")
            loc = f" (file: `{path}`, line: {line})" if path else ""
            lines.append(f"\n**{author}**{loc}:\n{body}\n")
        else:
            lines.append(f"\n**{author}**:\n{body}\n")

    comments_text = "".join(lines)
    repo_line = ""
    if repo_config:
        repo_line = f"## Repository: {repo_config.get('owner')}/{repo_config.get('name')}\n\n"
    return render_prompt(
        "runs/github-pr-mention.md",
        repo_line=repo_line,
        pr_url=pr_url,
        comments=comments_text,
    )


async def _fetch_paginated(
    client: httpx2.AsyncClient, url: str, headers: dict[str, str]
) -> list[dict[str, Any]]:
    """Fetch all pages from a GitHub paginated endpoint.

    Caps at ``PAGINATED_MAX_PAGES`` pages to avoid unbounded fetching on
    pathological PRs with thousands of comments.

    Args:
        client: An active httpx2 async client.
        url: The GitHub API endpoint URL.
        headers: Auth + accept headers.

    Returns:
        Combined list of all items across pages.
    """
    results: list[dict[str, Any]] = []
    params: dict[str, Any] = {"per_page": 100, "page": 1}

    while params["page"] <= PAGINATED_MAX_PAGES:
        try:
            response = await client.get(url, headers=headers, params=params)
            if response.status_code == 401:
                raise GitHubAuthError(f"GitHub returned 401 fetching {url}")
            if response.status_code != 200:  # noqa: PLR2004
                logger.warning("GitHub API returned %s for %s", response.status_code, url)
                break
            page_data = response.json()
            if not page_data:
                break
            results.extend(page_data)
            if len(page_data) < 100:  # noqa: PLR2004
                break
            params["page"] += 1
        except GitHubAuthError:
            raise
        except Exception:
            logger.exception("Failed to fetch %s", url)
            break

    return results
