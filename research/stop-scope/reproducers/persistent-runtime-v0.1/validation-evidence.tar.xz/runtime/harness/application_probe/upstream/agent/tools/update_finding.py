"""Tool: ``update_finding``. Mutate an existing finding by id."""

from typing import Any

from agent.review.findings import (
    DEFAULT_FINDING_TITLE,
    MAX_SUGGESTION_LINES,
    Finding,
    ReviewerThreadMissingError,
    clip_suggestion,
    comment_ids_for_finding,
    get_thread_id_from_runtime,
    list_findings,
    normalize_finding_title,
    resolve_review_head_sha,
    thread_ids_for_finding,
    thread_missing_tool_result,
    update_finding_fields,
)
from agent.run_config import RunConfig
from agent.utils.reviewer_outcomes import emit_finding_status_outcome


def _normalize_note(note: str | None) -> str | None:
    if note is None:
        return None
    normalized = note.strip()
    return normalized or None


def _has_published_github_surface(finding: Finding) -> bool:
    return bool(comment_ids_for_finding(finding) or thread_ids_for_finding(finding))


async def update_finding(
    finding_id: str,
    status: str | None = None,
    severity: str | None = None,
    confidence: str | None = None,
    title: str | None = None,
    description: str | None = None,
    suggestion: str | None = None,
    note: str | None = None,
) -> dict[str, Any]:
    """Implement the `update_finding` tool."""
    if status is not None and status not in {"open", "resolved", "dismissed"}:
        return {"success": False, "error": f"Invalid status: {status}"}
    if severity is not None and severity not in {"low", "medium", "high", "critical"}:
        return {"success": False, "error": f"Invalid severity: {severity}"}
    if confidence is not None and confidence not in {"low", "medium", "high"}:
        return {"success": False, "error": f"Invalid confidence: {confidence}"}
    normalized_note = _normalize_note(note)
    if status in {"resolved", "dismissed"} and normalized_note is None:
        return {
            "success": False,
            "error": "Resolving or dismissing a finding requires a note with the message to post.",
        }

    updates: dict[str, Any] = {}
    suggestion_dropped = False
    if status is not None:
        updates["status"] = status
    if severity is not None:
        updates["severity"] = severity
    if confidence is not None:
        updates["confidence"] = confidence
    if title is not None:
        normalized_title = normalize_finding_title(title)
        if normalized_title == DEFAULT_FINDING_TITLE:
            return {"success": False, "error": "title must be a non-empty generated headline"}
        updates["title"] = normalized_title
    if description is not None:
        updates["description"] = description
    if suggestion is not None:
        if suggestion == "":
            updates["suggestion"] = None
        else:
            clipped, suggestion_dropped = clip_suggestion(suggestion)
            if not suggestion_dropped:
                updates["suggestion"] = clipped
    if normalized_note is not None:
        updates["last_update_note"] = normalized_note
        if status in {"resolved", "dismissed"}:
            updates["resolution_note"] = normalized_note

    cfg = RunConfig.from_runtime()

    if not updates:
        if suggestion_dropped:
            return {
                "success": False,
                "suggestion_dropped": True,
                "error": (
                    f"Suggestion exceeded the {MAX_SUGGESTION_LINES}-line cap "
                    "and was rejected; no other fields were provided, so "
                    "nothing was updated. Only include `suggestion` for "
                    "small, obvious fixes."
                ),
            }
        return {"success": False, "error": "No fields provided to update"}

    thread_id = get_thread_id_from_runtime()
    try:
        findings = await list_findings(thread_id)
    except ReviewerThreadMissingError as exc:
        return thread_missing_tool_result(exc)
    finding = next((item for item in findings if item.get("id") == finding_id), None)
    if finding is None:
        return {"success": False, "error": f"No finding found with id {finding_id}"}

    delegated_resolution = False
    can_resolve_github_thread = bool(cfg.repo) and cfg.pr_number is not None
    if (
        status in {"resolved", "dismissed"}
        and can_resolve_github_thread
        and _has_published_github_surface(finding)
    ):
        from agent.tools.resolve_finding_thread import resolve_finding_thread

        resolve_result = await resolve_finding_thread(
            finding_id, status=status, note=normalized_note or ""
        )
        if not resolve_result.get("success"):
            return {
                "success": False,
                "error": "GitHub review thread resolution failed; finding was left open.",
                "github_resolution": resolve_result,
            }
        delegated_resolution = True
        updates.pop("status", None)
        updates.pop("last_update_note", None)
        updates.pop("resolution_note", None)
        if not updates:
            result: dict[str, Any] = {
                "success": True,
                "finding": resolve_result.get("finding"),
                "github_resolution": resolve_result,
            }
            if suggestion_dropped:
                result["suggestion_dropped"] = True
                result["warning"] = (
                    f"Suggestion exceeded the {MAX_SUGGESTION_LINES}-line cap and was "
                    "rejected — the finding's prior `suggestion` was left unchanged. "
                    "Only include `suggestion` for small, obvious fixes."
                )
            return result

    if status is not None and not delegated_resolution:
        try:
            head_sha = await resolve_review_head_sha(thread_id, cfg)
        except ReviewerThreadMissingError as exc:
            return thread_missing_tool_result(exc)
        if head_sha:
            updates["last_confirmed_sha"] = head_sha

    try:
        updated = await update_finding_fields(thread_id, finding_id, updates)
    except ReviewerThreadMissingError as exc:
        return thread_missing_tool_result(exc)
    if updated is None:
        return {"success": False, "error": f"No finding found with id {finding_id}"}
    if status in {"resolved", "dismissed"} and not delegated_resolution:
        await emit_finding_status_outcome(updated, status, cfg=cfg, thread_id=thread_id)
    result = {"success": True, "finding": updated}
    if suggestion_dropped:
        result["suggestion_dropped"] = True
        result["warning"] = (
            f"Suggestion exceeded the {MAX_SUGGESTION_LINES}-line cap and was "
            "rejected — the finding's prior `suggestion` was left unchanged "
            "and other fields were updated normally. Only include "
            "`suggestion` for small, obvious fixes."
        )
    return result
