import asyncio
import contextvars
import logging
from collections.abc import Mapping, Sequence
from typing import Any

from langchain_core.language_models.chat_models import BaseChatModel
from langchain_core.messages import BaseMessage, HumanMessage, SystemMessage
from pydantic import BaseModel, Field

from agent.input_messages import dynamic_context_hash, human_input, input_message_text
from agent.prompts import load_prompt
from agent.slack.code_channels import CODE_CHANNEL_SESSION_TS, rename_session
from agent.source_context import SourceContext

logger = logging.getLogger(__name__)

MAX_THREAD_TITLE_CHARS = 80
MAX_TITLE_INPUT_CHARS = 8_000
TITLE_GENERATION_MAX_TOKENS = 256
TITLE_GENERATION_TIMEOUT_SECONDS = 10
_background_tasks: set[asyncio.Task[None]] = set()
_inflight_thread_ids: set[str] = set()


class _ThreadTitle(BaseModel):
    title: str = Field(description="Concise, outcome-focused thread title, 3-8 words")


_TITLE_SYSTEM_PROMPT = load_prompt("thread-title.md")


def _thread_metadata(thread: Any) -> dict[str, Any]:
    if isinstance(thread, Mapping):
        metadata = thread.get("metadata")
    else:
        metadata = getattr(thread, "metadata", None)
    return dict(metadata) if isinstance(metadata, Mapping) else {}


def _title_input(messages: Sequence[BaseMessage]) -> str | None:
    texts: list[str] = []
    for message in messages:
        if dynamic_context_hash(message.content) is not None:
            continue
        text = (input_message_text(message.content) or message.text).strip()
        if text:
            texts.append(text)
    transcript = "\n\n".join(texts)
    return transcript[:MAX_TITLE_INPUT_CHARS] if transcript else None


def _normalize_title(title: str) -> str:
    normalized = " ".join(title.strip().strip("`\"'").split())
    normalized = " ".join(normalized.split()[:8]).rstrip(".")
    if len(normalized) <= MAX_THREAD_TITLE_CHARS:
        return normalized
    return normalized[:MAX_THREAD_TITLE_CHARS].rsplit(" ", 1)[0].rstrip()


async def generate_and_store_thread_title(
    *,
    thread_id: str,
    conversation: str,
    model: BaseChatModel,
    client: Any,
) -> None:
    thread = await client.threads.get(thread_id=thread_id)
    metadata = _thread_metadata(thread)
    expected_title = metadata.get("title")
    title_seed = metadata.get("title_seed")
    if (
        metadata.get("source") not in {"dashboard", "slack"}
        or not isinstance(title_seed, str)
        or expected_title != title_seed
    ):
        return

    structured = model.with_structured_output(_ThreadTitle)
    title_input = human_input(
        conversation,
        {
            "sender_id": "person:title-subject",
            "surface": "automation",
            "kind": "human",
        },
    )["content"]
    if not isinstance(title_input, str):
        return
    async with asyncio.timeout(TITLE_GENERATION_TIMEOUT_SECONDS):
        result = await structured.ainvoke(
            [
                SystemMessage(content=_TITLE_SYSTEM_PROMPT),
                HumanMessage(content=title_input),
            ],
            # Empty callbacks, so this call cannot inherit the run's handlers and
            # stream its tokens into the thread the user is watching.
            config={"callbacks": [], "run_name": "thread-title"},
        )
    if not isinstance(result, _ThreadTitle):
        return
    title = _normalize_title(result.title)
    if not title:
        return

    latest = await client.threads.get(thread_id=thread_id)
    latest_metadata = _thread_metadata(latest)
    if (
        latest_metadata.get("title") != expected_title
        or latest_metadata.get("title_seed") != title_seed
    ):
        return
    await client.threads.update(
        thread_id=thread_id,
        metadata={"title": title, "title_seed": None},
    )
    # Re-read after the update: the pre-update snapshot can be stale if the
    # thread was promoted to a code channel between the check and the update.
    latest = await client.threads.get(thread_id=thread_id)
    context = SourceContext.from_metadata(_thread_metadata(latest))
    if context.slack_location and context.slack_location[1] == CODE_CHANNEL_SESSION_TS:
        await rename_session(context.slack_location[0], title)


def schedule_thread_title_generation(
    *,
    thread_id: str,
    messages: Sequence[BaseMessage],
    model: BaseChatModel,
    client: Any,
) -> None:
    conversation = _title_input(messages)
    if conversation is None or thread_id in _inflight_thread_ids:
        return
    _inflight_thread_ids.add(thread_id)

    async def run() -> None:
        try:
            await generate_and_store_thread_title(
                thread_id=thread_id,
                conversation=conversation,
                model=model,
                client=client,
            )
        except Exception as exc:  # noqa: BLE001
            logger.warning("Thread title generation failed for %s: %s", thread_id, exc)
        finally:
            _inflight_thread_ids.discard(thread_id)

    # A fresh context, not the caller's: an inherited context carries LangGraph's
    # stream writer, and this call's structured-output chunks would then be
    # emitted into the run's message stream — rendering as a bogus assistant
    # message and derailing the client's assembly of every later chunk.
    task = asyncio.get_running_loop().create_task(run(), context=contextvars.Context())
    _background_tasks.add(task)
    task.add_done_callback(_background_tasks.discard)
