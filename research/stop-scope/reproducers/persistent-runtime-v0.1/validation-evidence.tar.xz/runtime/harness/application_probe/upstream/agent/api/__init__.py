"""FastAPI application composition."""
