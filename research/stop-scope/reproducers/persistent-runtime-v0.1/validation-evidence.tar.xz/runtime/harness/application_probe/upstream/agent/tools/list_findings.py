"""Tool: ``list_findings``. Return findings persisted on the reviewer thread."""

from typing import Any

from agent.review.findings import (
    ReviewerThreadMissingError,
    get_thread_id_from_runtime,
    thread_missing_tool_result,
)
from agent.review.findings import (
    list_findings as list_findings_async,
)


async def list_findings(status_filter: str | None = None) -> dict[str, Any]:
    """Implement the `list_findings` tool."""
    if status_filter is not None and status_filter not in {"open", "resolved", "dismissed"}:
        return {"findings": [], "count": 0, "error": f"Invalid status_filter: {status_filter}"}

    thread_id = get_thread_id_from_runtime()
    try:
        findings = await list_findings_async(thread_id)
    except ReviewerThreadMissingError as exc:
        return thread_missing_tool_result(exc)
    if status_filter is not None:
        findings = [f for f in findings if f.get("status") == status_filter]
    return {"findings": findings, "count": len(findings)}
