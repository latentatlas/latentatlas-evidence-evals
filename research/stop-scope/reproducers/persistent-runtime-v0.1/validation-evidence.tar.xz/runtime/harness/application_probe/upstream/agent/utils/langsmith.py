"""LangSmith trace URL utilities."""

import asyncio
import logging
import math
import uuid
from dataclasses import dataclass
from datetime import UTC, datetime
from typing import Any, Literal
from urllib.parse import unquote, urlsplit

from langsmith import AsyncClient as AsyncLangSmithClient
from langsmith import Client as LangSmithClient
from langsmith.utils import LangSmithNotFoundError, get_host_url

from agent.config import ENV
from agent.utils.tracing import tracing_project

logger = logging.getLogger(__name__)

# Both caches are keyed by the credentials that produced the ids, so a rotated
# key or another endpoint (a different workspace) starts over instead of
# building links with the previous workspace's tenant and project ids.
_PROJECT_ID_CACHE: dict[tuple[tuple[str, str], str], str] = {}
_TENANT_ID_CACHE: dict[tuple[str, str], str] = {}
_ASYNC_CLIENTS: dict[tuple[str, str], AsyncLangSmithClient] = {}
_SYNC_CLIENTS: dict[tuple[str, str], LangSmithClient] = {}


@dataclass(frozen=True)
class LangSmithThreadCost:
    total_cost: float
    last_end_time: datetime
    target_end_time: datetime


@dataclass(frozen=True)
class LangSmithLocator:
    kind: Literal["thread", "run"]
    id: str


class LangSmithCostUnavailable(RuntimeError):
    pass


def async_langsmith_client(api_key: str, api_url: str) -> AsyncLangSmithClient:
    """Return a pooled ``AsyncClient`` for these credentials.

    Each client owns an ``httpx2`` connection pool bound to the event loop that
    built it, so this assumes one loop per process. Keyed on the credentials so
    a test that repoints the env gets a fresh client instead of a stale pool.
    """
    key = (api_key, api_url)
    client = _ASYNC_CLIENTS.get(key)
    if client is None:
        client = _ASYNC_CLIENTS[key] = AsyncLangSmithClient(api_key=api_key, api_url=api_url)
    return client


def sync_langsmith_client(api_key: str, api_url: str) -> LangSmithClient:
    """Return a pooled sync ``Client``, for the few endpoints AsyncClient lacks."""
    key = (api_key, api_url)
    client = _SYNC_CLIENTS.get(key)
    if client is None:
        client = _SYNC_CLIENTS[key] = LangSmithClient(api_key=api_key, api_url=api_url)
    return client


def langsmith_host_url() -> str:
    """Web host for trace links, derived from the API endpoint."""
    return str(get_host_url(None, ENV.LANGSMITH_ENDPOINT.get())).rstrip("/")


def _build_langsmith_client() -> AsyncLangSmithClient | None:
    """Build the LangSmith client used for project lookups, or None without a key."""
    api_key = ENV.LANGSMITH_API_KEY.optional()
    if not api_key:
        return None
    return async_langsmith_client(api_key, ENV.LANGSMITH_ENDPOINT.get())


def _workspace_key() -> tuple[str, str]:
    return (ENV.LANGSMITH_API_KEY.optional() or "", ENV.LANGSMITH_ENDPOINT.get())


def _remember_tenant_id(value: Any) -> None:
    if value:
        _TENANT_ID_CACHE.setdefault(_workspace_key(), str(value))


def _discover_tenant_id() -> str | None:
    """Any project in the workspace carries the tenant id; read the first one."""
    api_key = ENV.LANGSMITH_API_KEY.optional()
    if not api_key:
        return None
    client = sync_langsmith_client(api_key, ENV.LANGSMITH_ENDPOINT.get())
    for project in client.list_projects(limit=1):
        tenant_id = getattr(project, "tenant_id", None)
        if tenant_id:
            return str(tenant_id)
    return None


async def resolve_tenant_id() -> str | None:
    """Discovered once and cached; ``LANGSMITH_TENANT_ID`` is an explicit override."""
    explicit = ENV.LANGSMITH_TENANT_ID.optional()
    if explicit:
        return explicit
    workspace = _workspace_key()
    cached = _TENANT_ID_CACHE.get(workspace)
    if cached:
        return cached
    try:
        discovered = await asyncio.to_thread(_discover_tenant_id)
    except Exception:  # noqa: BLE001
        logger.debug("Could not discover the LangSmith tenant id", exc_info=True)
        return None
    _remember_tenant_id(discovered)
    return _TENANT_ID_CACHE.get(workspace)


async def _resolve_project_id_by_name(project_name: str) -> str | None:
    """Resolve a LangSmith project id from its name, caching definitive results."""
    cache_key = (_workspace_key(), project_name)
    if cache_key in _PROJECT_ID_CACHE:
        return _PROJECT_ID_CACHE[cache_key] or None
    client = _build_langsmith_client()
    if client is None:
        return None
    try:
        project = await client.read_project(project_name=project_name)
    except LangSmithNotFoundError:
        _PROJECT_ID_CACHE[cache_key] = ""
        return None
    except Exception:  # noqa: BLE001
        logger.debug("Could not resolve LangSmith project id for %s", project_name, exc_info=True)
        return None
    project_id = getattr(project, "id", None)
    resolved = str(project_id) if project_id else ""
    _PROJECT_ID_CACHE[cache_key] = resolved
    _remember_tenant_id(getattr(project, "tenant_id", None))
    return resolved or None


async def _compose_langsmith_project_url(project_name: str | None = None) -> str | None:
    """URL base of a LangSmith project, or None when tracing isn't configured.

    Defaults to the project this deployment traces into; the review trace
    context passes the team-configured project it searches for the reviewed
    change's own traces.
    """
    tenant_id = await resolve_tenant_id()
    if not tenant_id:
        return None
    project_id = await _resolve_project_id_by_name(project_name or tracing_project())
    if not project_id:
        return None
    return f"{langsmith_host_url()}/o/{tenant_id}/projects/p/{project_id}"


async def get_langsmith_trace_url(thread_id: str, project_name: str | None = None) -> str | None:
    """Build the LangSmith thread URL for a given thread ID, or None if tracing
    isn't configured. This is a best-effort convenience link, not an error path."""
    project_url = await _compose_langsmith_project_url(project_name)
    return f"{project_url}/t/{thread_id}" if project_url else None


def _langsmith_web_origins() -> set[str]:
    values = ["https://smith.langchain.com", langsmith_host_url()]
    origins: set[str] = set()
    for value in values:
        try:
            parsed = urlsplit(value.strip())
            port = parsed.port
        except ValueError:
            continue
        if parsed.scheme not in {"http", "https"} or not parsed.hostname:
            continue
        default_port = 443 if parsed.scheme == "https" else 80
        suffix = f":{port}" if port is not None and port != default_port else ""
        origins.add(f"{parsed.scheme.lower()}://{parsed.hostname.lower()}{suffix}")
    return origins


def parse_langsmith_locator(locator: str) -> LangSmithLocator | None:
    """Parse a trusted LangSmith thread or run URL without fetching it."""
    value = locator.strip().strip("<>")
    if "|" in value:
        value = value.split("|", 1)[0]
    try:
        parsed = urlsplit(value)
        port = parsed.port
    except ValueError:
        return None
    if (
        parsed.scheme not in {"http", "https"}
        or not parsed.hostname
        or parsed.username is not None
        or parsed.password is not None
    ):
        return None
    default_port = 443 if parsed.scheme == "https" else 80
    suffix = f":{port}" if port is not None and port != default_port else ""
    origin = f"{parsed.scheme.lower()}://{parsed.hostname.lower()}{suffix}"
    if origin not in _langsmith_web_origins():
        return None
    segments = parsed.path.split("/")
    for index in range(len(segments) - 2, -1, -1):
        if segments[index] not in {"t", "r"} or index + 2 != len(segments):
            continue
        try:
            identifier = unquote(segments[index + 1], errors="strict")
        except UnicodeDecodeError:
            return None
        if not identifier or "/" in identifier:
            return None
        return LangSmithLocator(kind="thread" if segments[index] == "t" else "run", id=identifier)
    return None


async def get_open_swe_thread_id_from_langsmith(locator: str) -> str | None:
    """Resolve a LangSmith thread/run URL or run UUID to its Open SWE thread ID."""
    parsed = parse_langsmith_locator(locator)
    if parsed is None:
        try:
            run_id = str(uuid.UUID(locator.strip()))
        except ValueError, AttributeError:
            return None
        parsed = LangSmithLocator(kind="run", id=run_id)
    if parsed.kind == "thread":
        return parsed.id
    client = _build_langsmith_client()
    if client is None:
        return None
    try:
        run = await client.read_run(parsed.id)
    except Exception:  # noqa: BLE001
        logger.debug("Could not resolve LangSmith run %s", parsed.id, exc_info=True)
        return None
    metadata = _langsmith_value(run, "metadata")
    if not isinstance(metadata, dict):
        extra = _langsmith_value(run, "extra")
        metadata = extra.get("metadata") if isinstance(extra, dict) else None
    thread_id = metadata.get("thread_id") if isinstance(metadata, dict) else None
    return thread_id if isinstance(thread_id, str) and thread_id else None


def _langsmith_value(value: Any, name: str) -> Any:
    return value.get(name) if isinstance(value, dict) else getattr(value, name, None)


def _parse_langsmith_time(value: Any) -> datetime | None:
    if isinstance(value, datetime):
        return value if value.tzinfo else value.replace(tzinfo=UTC)
    if not isinstance(value, str) or not value:
        return None
    try:
        parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
    except ValueError:
        return None
    return parsed if parsed.tzinfo else parsed.replace(tzinfo=UTC)


def _langsmith_metadata_filter(key: str, value: str) -> str:
    escaped_key = key.replace("\\", "\\\\").replace('"', '\\"')
    escaped_value = value.replace("\\", "\\\\").replace('"', '\\"')
    return f'and(eq(metadata_key, "{escaped_key}"), eq(metadata_value, "{escaped_value}"))'


def _langsmith_invocation_filter(invocation_id: str) -> str:
    filters = [
        _langsmith_metadata_filter(key, invocation_id)
        for key in ("invocation_id", "prepare_run_id")
    ]
    return f"or({', '.join(filters)})"


def _langsmith_trace_filter(trace_ids: list[str]) -> str:
    filters = [f'eq(trace_id, "{trace_id}")' for trace_id in trace_ids]
    return filters[0] if len(filters) == 1 else f"or({', '.join(filters)})"


async def get_langsmith_thread_cost(
    thread_id: str,
    invocation_id: str,
    *,
    run_only: bool = False,
) -> LangSmithThreadCost | None:
    """Return fresh trace cost correlated to one completed invocation."""
    client = _build_langsmith_client()
    if client is None:
        raise LangSmithCostUnavailable("LangSmith credentials are not configured")
    project_id = await _resolve_project_id_by_name(tracing_project())
    if not project_id:
        raise LangSmithCostUnavailable("LangSmith tracing project is unavailable")
    try:
        roots = client.list_runs(
            project_id=project_id,
            is_root=True,
            filter=_langsmith_invocation_filter(invocation_id),
            select=["id", "end_time"],
        )
        matched_roots = [
            (str(root_id), parsed)
            async for run in roots
            if (root_id := _langsmith_value(run, "id"))
            and (parsed := _parse_langsmith_time(_langsmith_value(run, "end_time"))) is not None
        ]
        if not matched_roots:
            return None
        stats_kwargs: dict[str, Any] = {
            "session_id": project_id,
            "selects": ["TOTAL_COST", "LAST_END_TIME"],
        }
        if run_only:
            stats_kwargs["filter"] = _langsmith_trace_filter(
                [trace_id for trace_id, _ in matched_roots]
            )
        stats = await client.threads.stats(thread_id, **stats_kwargs)
    except LangSmithNotFoundError as exc:
        raise LangSmithCostUnavailable("LangSmith thread stats are unsupported") from exc
    except Exception as exc:  # noqa: BLE001
        status_code = getattr(exc, "status_code", None)
        if isinstance(status_code, int) and 400 <= status_code < 500 and status_code != 429:
            raise LangSmithCostUnavailable("LangSmith thread stats are unsupported") from exc
        logger.debug("Could not load LangSmith cost for thread %s", thread_id, exc_info=True)
        return None

    raw_cost = _langsmith_value(stats, "total_cost")
    if isinstance(raw_cost, bool):
        return None
    try:
        total_cost = float(raw_cost)
    except TypeError, ValueError:
        return None
    last_end_time = _parse_langsmith_time(_langsmith_value(stats, "last_end_time"))
    target_end_time = max(end_time for _, end_time in matched_roots)
    if (
        not math.isfinite(total_cost)
        or total_cost < 0
        or last_end_time is None
        or last_end_time < target_end_time
    ):
        return None
    return LangSmithThreadCost(
        total_cost=total_cost,
        last_end_time=last_end_time,
        target_end_time=target_end_time,
    )


def _build_langsmith_feedback_clients() -> tuple[tuple[str, str], ...]:
    """Resolve feedback client configs from current env. Re-read each call so
    rotated keys / late secret hydration are picked up."""
    configs: list[tuple[str, str]] = []
    seen: set[tuple[str, str]] = set()

    client_configs = ((ENV.LANGSMITH_API_KEY.optional(), ENV.LANGSMITH_ENDPOINT.get()),)

    for api_key, api_url in client_configs:
        if not api_key or not api_url:
            continue
        identity = (api_key, api_url)
        if identity in seen:
            continue
        configs.append(identity)
        seen.add(identity)

    return tuple(configs)


def _feedback_id(run_id: str, key: str) -> uuid.UUID:
    return uuid.uuid5(uuid.NAMESPACE_URL, f"langsmith-feedback:{run_id}:{key}")


async def create_langsmith_thread_feedback(
    thread_id: str,
    key: str,
    *,
    score: float | None,
    comment: str | None = None,
    source_info: dict[str, Any] | None = None,
) -> bool:
    client = _build_langsmith_client()
    if client is None:
        logger.warning("No LangSmith API key configured, skipping thread feedback")
        return False
    project_id = await _resolve_project_id_by_name(tracing_project())
    if not project_id:
        logger.warning("LangSmith tracing project is unavailable, skipping thread feedback")
        return False
    feedback_id = _feedback_id(thread_id, key)
    payload = {
        "id": str(feedback_id),
        "key": key,
        "score": score,
        "comment": comment,
        "session_id": project_id,
        "feedback_thread_id": thread_id,
        "feedback_source": {"type": "api", "metadata": source_info or {}},
    }
    try:
        await client._arequest_with_retries("POST", "/feedback", json=payload)  # noqa: SLF001
        return True
    except Exception:  # noqa: BLE001
        pass
    try:
        await client._arequest_with_retries(  # noqa: SLF001
            "PATCH",
            f"/feedback/{feedback_id}",
            json={"score": score, "comment": comment},
        )
        return True
    except Exception:
        logger.exception("Failed to create or update LangSmith thread feedback for %s", thread_id)
        return False


async def _update_feedback(
    api_key: str,
    api_url: str,
    feedback_id: uuid.UUID,
    *,
    score: float,
    comment: str | None,
) -> None:
    # AsyncClient exposes no update_feedback; the sync one runs off-loop.
    client = sync_langsmith_client(api_key, api_url)
    await asyncio.to_thread(client.update_feedback, feedback_id, score=score, comment=comment)


async def create_langsmith_feedback(
    run_id: str,
    key: str,
    *,
    score: float,
    comment: str | None = None,
    source_info: dict[str, Any] | None = None,
) -> bool:
    """Create or update deterministic feedback on all configured LangSmith tenants."""
    configs = _build_langsmith_feedback_clients()
    if not configs:
        logger.warning("No LangSmith API key configured, skipping feedback")
        return False

    feedback_id = _feedback_id(run_id, key)
    any_success = False
    for api_key, api_url in configs:
        try:
            await async_langsmith_client(api_key, api_url).create_feedback(
                run_id=run_id,
                key=key,
                score=score,
                comment=comment,
                source_info=source_info,
                feedback_source_type="api",
                feedback_id=feedback_id,
            )
            any_success = True
            continue
        except Exception:  # noqa: BLE001 - feedback already exists; update in place
            pass
        try:
            await _update_feedback(api_key, api_url, feedback_id, score=score, comment=comment)
            any_success = True
        except Exception:
            logger.exception("Failed to create or update LangSmith feedback for run %s", run_id)
    return any_success


async def delete_langsmith_feedback(run_id: str, key: str) -> bool:
    """Delete deterministic feedback from all configured LangSmith tenants."""
    configs = _build_langsmith_feedback_clients()
    if not configs:
        logger.warning("No LangSmith API key configured, skipping feedback deletion")
        return False

    feedback_id = _feedback_id(run_id, key)
    any_success = False
    for api_key, api_url in configs:
        try:
            await async_langsmith_client(api_key, api_url).delete_feedback(feedback_id)
            any_success = True
        except LangSmithNotFoundError:
            any_success = True
        except Exception:
            logger.exception("Failed to delete LangSmith feedback for run %s", run_id)
    return any_success
