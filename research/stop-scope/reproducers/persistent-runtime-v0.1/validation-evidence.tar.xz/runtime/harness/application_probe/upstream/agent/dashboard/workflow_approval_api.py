"""REST API for approving workflow-file pushes."""

from typing import Any

from fastapi import APIRouter, Depends, HTTPException

from agent.dashboard.oauth import require_same_origin_for_mutations, require_session
from agent.dashboard.plan_api import dispatch_followup, fetch_thread_metadata
from agent.dashboard.threads.summary import thread_is_promptable, thread_is_readable
from agent.dashboard.workflow_approval import (
    decide_workflow_push_approval,
    get_workflow_push_approvals,
    workflow_push_approval_responses,
)

workflow_approval_router = APIRouter(
    prefix="/dashboard/api/workflow-approval",
    tags=["workflow-approval"],
    dependencies=[Depends(require_same_origin_for_mutations)],
)
_SESSION_DEP = Depends(require_session)


@workflow_approval_router.get("/{thread_id}")
async def list_workflow_push_approvals(
    thread_id: str, session: dict[str, Any] = _SESSION_DEP
) -> dict[str, Any]:
    metadata = await fetch_thread_metadata(thread_id)
    if not thread_is_readable(metadata, session["sub"], session.get("email")):
        raise HTTPException(404, "thread not found")
    approvals = await get_workflow_push_approvals(thread_id)
    return {
        "threadId": thread_id,
        "approvals": workflow_push_approval_responses(approvals),
    }


@workflow_approval_router.post("/{thread_id}/{fingerprint}/approve")
async def approve_workflow_push(
    thread_id: str, fingerprint: str, session: dict[str, Any] = _SESSION_DEP
) -> dict[str, Any]:
    metadata = await fetch_thread_metadata(thread_id)
    if not thread_is_promptable(metadata, session["sub"]):
        raise HTTPException(404, "thread not found")
    record = await decide_workflow_push_approval(
        thread_id, fingerprint, approved=True, actor=session["sub"]
    )
    if record is None:
        raise HTTPException(404, "workflow push approval not found")
    await dispatch_followup(
        thread_id,
        metadata,
        "The workflow-file push approval was approved. Retry the blocked git push now; do not alter workflow files before pushing.",
        plan_mode=False,
    )
    return {"status": "approved", "fingerprint": fingerprint}


@workflow_approval_router.post("/{thread_id}/{fingerprint}/reject")
async def reject_workflow_push(
    thread_id: str, fingerprint: str, session: dict[str, Any] = _SESSION_DEP
) -> dict[str, Any]:
    metadata = await fetch_thread_metadata(thread_id)
    if not thread_is_promptable(metadata, session["sub"]):
        raise HTTPException(404, "thread not found")
    record = await decide_workflow_push_approval(
        thread_id, fingerprint, approved=False, actor=session["sub"]
    )
    if record is None:
        raise HTTPException(404, "workflow push approval not found")
    return {"status": "rejected", "fingerprint": fingerprint}
