"""Packaging checks use copies; retained research evidence is never modified."""
import json
import os
from pathlib import Path
import shutil
import tempfile
import unittest
from unittest.mock import patch
import run
from verify import verify_episode, total_calls

class PortableTests(unittest.TestCase):
    def test_unknown_usage_does_not_become_zero(self):
        self.assertIsNone(total_calls({"known":{"actual_provider_calls":3}, "unknown":{"actual_provider_calls":None}}))

    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory()
        self.root=Path(self.tmp.name).resolve()
        self.evidence=Path(os.environ["STOP_SCOPE_TEST_EVIDENCE"]).resolve()
    def tearDown(self):self.tmp.cleanup()
    def copy(self):
        target=self.root/"episode";shutil.copytree(self.evidence,target);return target
    def test_real_evidence_recomputed(self):
        result=verify_episode(self.evidence)
        self.assertEqual(result["evidence_status"],"recorded")
    def test_added_file_rejected(self):
        out=self.copy();(out/"unrecorded.txt").write_text("extra")
        with self.assertRaisesRegex(ValueError,"inventory"):verify_episode(out)
    def test_missing_file_rejected(self):
        out=self.copy();(out/"DATABASE_FINAL.json").unlink()
        with self.assertRaisesRegex(ValueError,"inventory"):verify_episode(out)
    def test_symlink_rejected(self):
        out=self.copy();(out/"alias").symlink_to(out/"PLAN.json")
        with self.assertRaisesRegex(ValueError,"Symlink"):verify_episode(out)
    def test_resigned_usage_tamper_fails_semantic_audit(self):
        out=self.copy();p=out/"USAGE.json";usage=json.loads(p.read_text());usage["actual_provider_calls"]=5
        p.write_text(json.dumps(usage))
        p=out/"COMPLETION.json";completion=json.loads(p.read_text())
        actual=run.inventory(out);actual.pop("COMPLETION.json");completion["artifact_hashes"]=actual;p.write_text(json.dumps(completion))
        with self.assertRaisesRegex(ValueError,"Recomputed audit"):verify_episode(out)
    def test_extra_executable_source_rejected(self):
        harness=self.root/"harness";main=harness/"main";main.mkdir(parents=True)
        (harness/"known.py").write_text("x=1")
        manifest={"files":{"harness/known.py":run.sha(harness/"known.py")}}
        (main/"SOURCE_MANIFEST.json").write_text(json.dumps(manifest))
        with patch.object(run,"ROOT",self.root),patch.object(run,"HERE",main):
            self.assertEqual(run.verify_sources(),manifest["files"])
            (harness/"shadow.py").write_text("x=2")
            with self.assertRaisesRegex(ValueError,"inventory"):run.verify_sources()
    def test_live_refused_without_explicit_switches(self):
        with patch("sys.argv",["run.py","--live","--out",str(self.root/"must-not-exist")]):
            with self.assertRaisesRegex(ValueError,"explicit API cost"):run.cli()
        self.assertFalse((self.root/"must-not-exist").exists())
    def test_existing_output_refused_without_rewriting(self):
        out=self.root/"existing";out.mkdir();f=out/"sentinel";f.write_text("preserve")
        with self.assertRaisesRegex(ValueError,"immutable"):run.execute(out)
        self.assertEqual(f.read_text(),"preserve")

if __name__=="__main__":unittest.main()

